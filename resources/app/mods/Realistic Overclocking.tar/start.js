let _modPath;

exports.initialize = (modPath) =>{
	let modName = 'Realistic Overclocking';
	let modName_simple = modName.toLowerCase().replace(/\s/g, '');
	_modPath = modPath;

    // Modified function from original - Startup Company v1.24
    // total: (e.power / 1.4 * (( (null == e.clockRate ? 100 : e.clockRate) / 100) * ( (null == e.clockRate ? 100 : e.clockRate) / 100))) + e.power / 3.5
    // per device: (e.power / 1.4 * (t * t)) + e.power / 3.5
    Helpers.GetRackPerformance = function (e,t) {
        let n = {
            id: e.id
        }
          , a = e.layout.filter(e=>null != e.deviceName && 1 == e.powered).map(e=>{
            let t = Helpers.Clone(RackDevices[e.deviceName]);
            return t.id = e.id,
            t.clockRate = e.clockRate,
            t.lastPatchDay = e.lastPatchDay,
            t
        }
        );
        // modified formula total
        n.totalConsumedPower = _.sum(a.map(e=>(e.power / 1.4 * (( (null == e.clockRate ? 100 : e.clockRate) / 100) * ( (null == e.clockRate ? 100 : e.clockRate) / 100))) + e.power / 3.5));
        let i = Math.max(_.sum(a.map(e=>{
            let t = null == e.clockRate ? 100 : e.clockRate;
            return e.producedHeat * (t / 100)
        }
        )), 0)
          , r = t;
        n.rackTemperature = Math.round(Math.max(r, r + i / 3)),
        n.devices = [];
        for (const e of a) {
            let t = (null == e.clockRate ? 100 : e.clockRate) / 100
              , a = Math.round(Math.max((n.rackTemperature + e.producedHeat) * t, r))
              , i = 0
              , o = Enums.RackDeviceState.Running;
            if (e.producedHeat > 0) {
                a >= (e.reducedPerformance || 70) && (i = 20,
                o = Enums.RackDeviceState.ReducedPerformance);
                const t = e.overheatProtection || 100;
                a >= t && (i = 100,
                o = Enums.RackDeviceState.OverheatProtection,
                a = t)
            }
            null != e.requirements && null == e.lastPatchDay && (o = Enums.RackDeviceState.NotConfigured,
            i = 100),
            i = (100 - i) / 100,
            n.devices.push({
                id: e.id,
		        // modified formula per device
                consumedPower: Math.round((e.power / 1.4 * (t * t)) + e.power / 3.5),
                state: o,
                temperature: a,
                webserverThroughput: null != e.webserverThroughput ? Math.round(e.webserverThroughput * t * i) : null,
                cacheThroughput: null != e.cacheThroughput ? Math.round(e.cacheThroughput * t * i) : null,
                databaseThroughput: null != e.databaseThroughput ? Math.round(e.databaseThroughput * t * i) : null
            })
        }
        return n.totalCacheThroughput = _.sum(n.devices.map(e=>e.cacheThroughput)),
        n.totalDatabaseThroughput = _.sum(n.devices.map(e=>e.databaseThroughput)),
        n.totalWebserverThroughput = _.sum(n.devices.map(e=>e.webserverThroughput)),
        n.generatedHeat = i,
        n
    }
};



exports.onLoadGame = settings => {
    // Need to update the racks but can only work once the interface is loaded.
    setTimeout(()=>{
		let modName = 'Realistic Overclocking';
		let rootScope = GetRootScope();
    	console.log(modName + " broadcasting RackChange");
	    rootScope.$broadcast(Enums.GameEvents.RackChange);
    }
    , 5000);
};
exports.onNewHour = settings => {};
exports.onNewDay = settings => {};
exports.onUnsubscribe = done => {};


let _modPath;

exports.initialize = (modPath) =>{
    let modName = 'TreePlan';
    _modPath = modPath;
    Modding.setMenuItem({
        name: modName.toLowerCase(),
        tooltip: "Tree Plan",
        tooltipPosition: 'top',
        faIcon: 'fa-cubes',
        badgeCount: 0,
    });
    // Create view and logic
    exports.views = [{
        name: modName.toLowerCase(),
        viewPath: _modPath + 'view.html',
        controller: ["$scope", function ($scope) {
            $scope.modName = modName;
            
            const modes = {SEARCH: "search", TREE: "tree", PLAN: "plan"};
            $scope.modes = modes;
            $scope.mode = modes.SEARCH;
            let getName = function(name) {
                return Helpers.GetLocalized(name) || "unknown"
            };
            $scope.getName = getName;

            // componentMap {name: Component}
            componentMap = {};
            Components.map(x => componentMap[x.name] = x);
            $scope.componentMap = componentMap;

            // Dropdown
            const kindNames = {
                "all": Helpers.GetLocalized("all"),
                "features": Helpers.GetLocalized("features"),
                "servers": Helpers.GetLocalized("help_hosting_types_virtual_servers_headline"),
                "rackdevices": Helpers.GetLocalized("help_racks_servers"),
                "marketing": Helpers.GetLocalized("marketing"),
                "designer": Helpers.GetLocalized("designer"),
                "developer": Helpers.GetLocalized("developer"),
                "leaddeveloper": Helpers.GetLocalized("leaddeveloper"),
                "sysadmin": Helpers.GetLocalized("sysadmin")
            };
            $scope.kindNames = kindNames;
            $scope.ddKind = Object.keys(kindNames).map(
                x => ({kind: x, text: kindNames[x]})
            );
            $scope.cond = $scope.ddKind[0];

            // Tree to array
            function Branch(name, amount, level) {
                this.component = componentMap[name];
                this.name = name;
                this.text = getName(name)
                this.amount = amount;
                this.level = level;
                this.marketValue = GetRootScope().settings.marketValues[name].basePrice;
            }
            function traceBranch(branch, hist) {
                if (branch.level > 10 && branch.name in hist) {
                    console.debug("found inf loop");
                    return [];
                }
                let branches = [];
                branches.push(branch);
                if (branch.component.requirements) {
                    for (let name in branch.component.requirements) {
                        let amount = branch.component.requirements[name] * branch.amount;
                        let child = new Branch(name, amount, branch.level + 1);
                        hist.push(name);
                        branches = branches.concat(traceBranch(child, hist));
                        hist.pop();
                    }
                }
                return branches
            }
            // Plan
            $scope.selectedTargets = [];
            function Plan(component, text, totalAmount, basePrice) {
                this.component = component;
                this.text = text;
                this.totalAmount = totalAmount;
                this.basePrice = basePrice;
                this.produceHours = costMap[component.name].hours;
            }
            Plan.prototype.getTotalPrice = function() {
                return this.basePrice * this.totalAmount
            };
            $scope.planMap = {};
            function getPlanMap(targets) {
                // {"ComponentName": Plan}
                let calcMap = {};
                targets.map(t => {
                    if (t.branches) {
                        t.branches.map(b => {
                            if (b.name in calcMap === false) {
                                let basePrice = GetRootScope().settings.marketValues[b.name].basePrice;
                                calcMap[b.name] = new Plan(
                                    b.component,
                                    b.text,
                                    b.amount * t.amount,
                                    basePrice
                                );
                            } else {
                                let plan = calcMap[b.name];
                                plan.totalAmount += b.amount * t.amount;
                            }
                        })
                    } else {
                        if (t.body.name in calcMap === false) {
                            let basePrice = GetRootScope().settings.marketValues[t.body.name].basePrice;
                            calcMap[t.body.name] = new Plan(
                                t.body,
                                t.text,
                                t.amount,
                                basePrice
                            );
                        } else {
                            let plan = calcMap[t.body.name];
                            plan.totalAmount += t.amount * t.amount;
                        }
                    }
                });
                // {"EmployeeType": [Plan, Plan, ..], ..}
                let planMap = {};
                Object.values(calcMap).map(x => {
                    let empType = x.component.employeeTypeName;
                    let plans = planMap[empType] || [];
                    plans.push(x);
                    planMap[empType] = plans
                });
                let inventory = GetRootScope().settings.inventory;
                for (let empType in planMap) {
                    let totalAmount = planMap[empType].map(x => x.totalAmount);
                    planMap[empType].map(x => {
                        x.inStock = inventory[x.component.name] ? inventory[x.component.name] : 0;
                    });
                }
                if (planMap.Researcher && planMap.Researcher.length > 0)  {
                    planMap.Researcher[0].inStock = GetRootScope().settings.researchPoints;
                }
                return planMap;
            };

            // {name: {cost: 16, hours: 8}}
            let costMap = {};
            function calcCost(c) {
                return c.produceHours && {hours: c.produceHours, cost: c.produceHours} ||
                    c.requirements && Object.keys(c.requirements).map(
                        name => {
                            // ProduceHours * Amount
                            let tmp = calcCost(componentMap[name]);
                            let amount = c.requirements[name];
                            return {hours: tmp.hours * amount, cost: tmp.cost * amount}
                        }
                    ).reduce((a, v) => {
                        a.hours += v.hours;
                        // requirements cost + merge cost
                        a.cost += v.cost + v.hours;
                        return a
                    }, {hours: 0, cost: 0}) ||
                    c.name === "ResearchPoint" && {hours: 1, cost: 1} ||
                    {hours: 0, cost: 0};
            }
            Components.map(c => {
                costMap[c.name] = calcCost(c);
            });
            $scope.costMap = costMap;
            $scope.subRemainCost = function(plans) {
                return plans.reduce((a, p) => (a + p.produceHours * (
                    p.inStock < p.totalAmount ? p.totalAmount - p.inStock : 0)
                ), 0);
            };
            $scope.subTotalCost = function(plans) {
                return plans.reduce((a, p) => (a + p.produceHours * p.totalAmount), 0);
            };
            function wrapTarget(kind) {
                return function(o) {
                    let item = {};
                    item.body = o;
                    item.kind = kind;
                    item.kindText = kindNames[kind];
                    item.selected = false;
                    item.amount = 1;
                    item.text = getName(o.name);
                    if (o.requirements) {
                        let branches = [];
                        item.cost = 0;
                        for (let name in o.requirements) {
                            let amount = o.requirements[name];
                            item.cost += costMap[name].cost * amount;
                            let branch = new Branch(name, amount, 0);
                            branches = branches.concat(traceBranch(branch, []));
                        }
                        item.branches = branches;
                    } else {
                      item.cost = o.produceHours || 0;
                    }
                    return item
                }
            }
            // Keyword
            $scope.query = '';

            function createComponentGroups() {
              const targetTypes = ["Designer", "Developer", "LeadDeveloper", "SysAdmin"];
              const g = {};
              Components.map(x => {
                if (targetTypes.indexOf(x.employeeTypeName) >= 0) {
                  g[x.employeeTypeName] = g[x.employeeTypeName] || [];
                  g[x.employeeTypeName].push(x)
                }
              });
              // sort beginner to expert
              const order = {
                [EmployeeLevels.Beginner]: 0,
                [EmployeeLevels.Intermediate]: 1,
                [EmployeeLevels.Expert]: 2,
              }; 
              Object.keys(g).map(et => {
                g[et].sort((a,b) => (order[a.employeeLevel] - order[b.employeeLevel]))
              });
              return g;
            }
            const componentGroups = createComponentGroups();
            // Targets
            $scope.targets = [].concat(
                [].concat(
                    Features.map(wrapTarget('features')),
                    Servers.map(wrapTarget('servers')),
                    Object.values(RackDevices).map(wrapTarget('rackdevices')),
                    MarketingPackages.map(wrapTarget('marketing')),
                ).filter(x => (x.body.requirements && Object.keys(x.body.requirements).length > 0)),
                componentGroups.Designer.map(wrapTarget('designer')),
                componentGroups.Developer.map(wrapTarget('developer')),
                componentGroups.LeadDeveloper.map(wrapTarget('leaddeveloper')),
                componentGroups.SysAdmin.map(wrapTarget('sysadmin'))
            );
            $scope.filterTargets = (v, i, a) => (
                // dropdown
                (!$scope.cond || $scope.cond.kind === 'all' || $scope.cond.kind === v.kind)
                // keyword
                && (!$scope.query || v.text.indexOf($scope.query) >= 0
                    || v.body.name.toLowerCase().indexOf($scope.query.toLowerCase()) >= 0)
                // already selected
                || v.selected
            );
            // Checkbox click event
            $scope.toggleTargetSelection = function(row, e) {
                e.preventDefault();
                row.selected = !row.selected;
                $scope.selectedTargets = $scope.targets.filter(x=>x.selected);
                return true;
            };
            // Amount click event(disabled):
            $scope.clickAmount = function(e) {
                e.target.setSelectionRange(0, e.target.value.length);
            };
            // Amount input blur event
            $scope.blurAmount = function(row, e) {
                if (/^\d+$/.test(row.amount) && row.amount > 0) {
                    // ok
                } else {
                    row.amount = 1;
                }
            };

            // Switch view
            $scope.showSearch = function() {
                $scope.mode = modes.SEARCH;
            };
            $scope.showTree = function() {
                $scope.mode = modes.TREE;
            };
            $scope.showPlan = function() {
                $scope.planMap = getPlanMap($scope.selectedTargets);
                $scope.newPlanName = Helpers.GetLocalized("plan_x",{number: GetRootScope().settings.productionPlans.length+1});
                $scope.ddPlans = [{id: null, name: "[Create New Plan]"}].concat(GetRootScope().settings.productionPlans)
                let researchedMap = {};
                let researchedComponents = ResearchItems.filter(item=>(item.category=='Production')).map( 
                    item => {
                        let isResearched = GetRootScope().settings.researchedItems.indexOf(item.name) >= 0;
                        return item.unlocks.map(name=>{ researchedMap[name] = isResearched })
                    }
                );
                // The ResearchPoint has already researched since game started.
                researchedMap.ResearchPoint = true;

                $scope.researchedMap = researchedMap;
                $scope.canSave = Object.values($scope.planMap).every(
                    plans => plans.every(
                        plan => $scope.researchedMap[plan.component.name]
                    )
                );
                $scope.overwritingPlan = $scope.ddPlans[0];
                $scope.mode = modes.PLAN;
                $scope.planMessage = '';
            };

            $scope.generateFor = function (n) {
                let a = [];
                for (let i=1; i<=n; i++) {
                    a.push(i)
                }
                return a;
            };
            $scope.spacerStyle = function(i, level) {
                let style = {width: '25px', height: '25px', marginBottom: '25px', marginLeft: '25px'};
                if (i === level) {
                    Object.assign(style, {borderLeft: "solid 1px", borderBottom: "solid 1px"});
                }
                return style;
            };


            // Plan
            $scope.newPlanName = '';
            $scope.ddPlans = [];
            $scope.overwritingPlan = {};
            $scope.toggleIsOverwriting = function() {
                $scope.isOverwriting = !$scope.isOverwriting;
            };
            function createPlan(newPlanName, production) {
                let data = {
                    id: chance.guid(),
                    name: newPlanName,
                    production: production,
                    skipModulesWithMissingRequirements:true,
                    exceedTargets:true
                };
                GetRootScope().settings.productionPlans.push(data);
            }
            $scope.submitPlan = function() {
                let production = {};
                Object.values($scope.planMap).map(plans => 
                    plans.map(x => (production[x.component.name] = x.totalAmount))
                );
                if ($scope.overwritingPlan.id === null) {
                    // create plan
                    createPlan($scope.newPlanName, production);
                    let message = "[" + $scope.newPlanName + "] has been created.";
                    $scope.showPlan();
                    $scope.planMessage = message;
                    $scope.newPlanName = '';
                } else {
                    // overwrite plan
                    $scope.overwritingPlan.production = production;
                    $scope.planMessage = "[" + $scope.overwritingPlan.name + "] has been overwritten.";
                }
            };


        }]
    }];
};

exports.onLoadGame = settings => {};
exports.onNewHour = settings => {};
exports.onNewDay = settings => {};
exports.onUnsubscribe = done => {};

